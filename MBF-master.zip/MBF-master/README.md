# MBF Hack Facebook Terbaru [ YOCHIN ]

Script MBF login menggunakan cookies anti check points untuk hack akun Facebook.

# Cara install

$ pkg update && pkg upgrade

$ pkg install git curl python

$ pkg install ruby

$ gem install lolcat

$ termux-setup-storage

$ pip install mechanize requests bs4 futures

$ git clone 

$ cd MBF

$ python mbf.py

# FACEBOOK

YOCHIN

# WHATSAPP

083175817046
